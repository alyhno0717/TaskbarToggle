// Included inside main.cpp's private namespace. All coordinates are physical
// virtual-desktop coordinates under PerMonitorV2 DPI awareness.
constexpr unsigned int kMaxRecoveryMonitors = 64;

const MonitorSnapshot* FindMonitor(const std::vector<MonitorSnapshot>& monitors,
                                   const std::wstring& device) {
    for (const auto& monitor : monitors)
        if (monitor.device == device) return &monitor;
    return nullptr;
}

bool SameMonitor(const MonitorSnapshot& a, const MonitorSnapshot& b) {
    return a.device == b.device && EqualRectValue(a.bounds, b.bounds);
}

bool CanReuseWorkArea(const MonitorSnapshot& saved, const MonitorSnapshot& current) {
    return SameMonitor(saved, current) && ValidRectOnMonitor(saved.work, current.bounds) &&
           (!saved.taskbarDpi || saved.taskbarDpi == current.taskbarDpi);
}

bool SameDisplayLayout(const std::vector<MonitorSnapshot>& a,
                       const std::vector<MonitorSnapshot>& b) {
    if (a.size() != b.size()) return false;
    for (const auto& monitor : a) {
        const auto* other = FindMonitor(b, monitor.device);
        if (!other || !SameMonitor(monitor, *other)) return false;
    }
    return true;
}

BOOL CALLBACK CaptureMonitor(HMONITOR handle, HDC, LPRECT, LPARAM context) {
    auto& monitors = *reinterpret_cast<std::vector<MonitorSnapshot>*>(context);
    MONITORINFOEXW info{};
    info.cbSize = sizeof(info);
    if (!GetMonitorInfoW(handle, &info) ||
        !ValidRectOnMonitor(info.rcWork, info.rcMonitor)) return FALSE;
    monitors.push_back({handle, info.szDevice, info.rcMonitor, info.rcWork, false});
    return TRUE;
}

bool ReadMonitors(std::vector<MonitorSnapshot>& monitors) {
    monitors.clear();
    return EnumDisplayMonitors(nullptr, nullptr, CaptureMonitor,
        reinterpret_cast<LPARAM>(&monitors)) && !monitors.empty();
}

struct TaskbarCapture {
    DWORD shellPid;
    std::vector<MonitorSnapshot>& monitors;
    std::vector<TaskbarSnapshot>& taskbars;
};

BOOL CALLBACK CaptureTaskbar(HWND window, LPARAM context) {
    auto& capture = *reinterpret_cast<TaskbarCapture*>(context);
    wchar_t className[128]{};
    GetClassNameW(window, className, 128);
    if (wcscmp(className, L"Shell_TrayWnd") != 0 &&
        wcscmp(className, L"Shell_SecondaryTrayWnd") != 0) return TRUE;
    DWORD pid{};
    GetWindowThreadProcessId(window, &pid);
    if (pid != capture.shellPid) return TRUE;
    const auto handle = MonitorFromWindow(window, MONITOR_DEFAULTTONEAREST);
    for (auto& monitor : capture.monitors) {
        if (monitor.handle != handle) continue;
        capture.taskbars.push_back({window, pid, monitor.device});
        if (IsWindowVisible(window)) monitor.taskbarVisible = true;
        monitor.taskbarDpi = GetDpiForWindow(window);
        break;
    }
    return TRUE;
}

bool GetDesktopState(std::vector<MonitorSnapshot>& monitors,
                     std::vector<TaskbarSnapshot>& taskbars, DWORD& shellPid) {
    const HWND primary = FindWindowW(L"Shell_TrayWnd", nullptr);
    if (!primary || !ReadMonitors(monitors)) return false;
    GetWindowThreadProcessId(primary, &shellPid);
    taskbars.clear();
    TaskbarCapture capture{shellPid, monitors, taskbars};
    if (!EnumWindows(CaptureTaskbar, reinterpret_cast<LPARAM>(&capture))) return false;
    return std::any_of(taskbars.begin(), taskbars.end(), [primary](const auto& item) {
        return item.window == primary;
    });
}

std::wstring RecoverySection(unsigned int index) {
    return L"Recovery.Monitor" + std::to_wstring(index);
}

void ClearRecovery() {
    // Invalidate first: interrupted cleanup cannot leave an active partial record.
    WriteNumber(L"Recovery", L"Active", 0);
    const UINT count = GetPrivateProfileIntW(L"Recovery", L"Count", 0, g_configPath.c_str());
    for (UINT index = 0; index < std::min(count, kMaxRecoveryMonitors); ++index)
        WritePrivateProfileStringW(RecoverySection(index).c_str(), nullptr, nullptr,
                                   g_configPath.c_str());
    WritePrivateProfileStringW(L"Recovery", nullptr, nullptr, g_configPath.c_str());
}

bool WriteRecoveryRect(const wchar_t* section, const wchar_t* prefix, const RECT& rect) {
    const std::wstring key(prefix);
    return WriteNumber(section, (key + L"Left").c_str(), rect.left) &&
           WriteNumber(section, (key + L"Top").c_str(), rect.top) &&
           WriteNumber(section, (key + L"Right").c_str(), rect.right) &&
           WriteNumber(section, (key + L"Bottom").c_str(), rect.bottom);
}

RECT ReadRecoveryRect(const wchar_t* section, const wchar_t* prefix) {
    const std::wstring key(prefix);
    return {
        static_cast<LONG>(GetPrivateProfileIntW(section, (key + L"Left").c_str(), 0, g_configPath.c_str())),
        static_cast<LONG>(GetPrivateProfileIntW(section, (key + L"Top").c_str(), 0, g_configPath.c_str())),
        static_cast<LONG>(GetPrivateProfileIntW(section, (key + L"Right").c_str(), 0, g_configPath.c_str())),
        static_cast<LONG>(GetPrivateProfileIntW(section, (key + L"Bottom").c_str(), 0, g_configPath.c_str()))};
}

// Written at a toggle, with Active committed last; no background timer.
bool SaveRecovery(const std::vector<MonitorSnapshot>& monitors, DWORD shellPid) {
    if (monitors.empty() || monitors.size() > kMaxRecoveryMonitors) return false;
    ClearRecovery();
    if (!WriteNumber(L"Recovery", L"Format", 2) ||
        !WriteNumber(L"Recovery", L"ExplorerPid", shellPid) ||
        !WriteNumber(L"Recovery", L"Count", monitors.size())) return false;
    for (UINT index = 0; index < monitors.size(); ++index) {
        const auto& monitor = monitors[index];
        const auto section = RecoverySection(index);
        if (!WritePrivateProfileStringW(section.c_str(), L"Device", monitor.device.c_str(), g_configPath.c_str()) ||
            !WriteRecoveryRect(section.c_str(), L"Monitor", monitor.bounds) ||
            !WriteRecoveryRect(section.c_str(), L"", monitor.work) ||
            !WriteNumber(section.c_str(), L"TaskbarVisible", monitor.taskbarVisible) ||
            !WriteNumber(section.c_str(), L"TaskbarDpi", monitor.taskbarDpi)) return false;
    }
    if (!WriteNumber(L"Recovery", L"Active", 1)) return false;
    // This cache-flush form returns zero even when it succeeds (Win32 contract).
    WritePrivateProfileStringW(nullptr, nullptr, nullptr, g_configPath.c_str());
    return true;
}

bool ReadRecovery(std::vector<MonitorSnapshot>& monitors,
                   const std::vector<MonitorSnapshot>& current) {
    monitors.clear();
    const UINT format = GetPrivateProfileIntW(L"Recovery", L"Format", 1, g_configPath.c_str());
    if (format == 1) {
        // Versions <= 1.0.2 persisted a single primary monitor without a device name.
        const RECT bounds = ReadRecoveryRect(L"Recovery", L"Monitor");
        const RECT work = ReadRecoveryRect(L"Recovery", L"");
        if (!ValidRectOnMonitor(work, bounds)) return false;
        const auto handle = MonitorFromWindow(FindWindowW(L"Shell_TrayWnd", nullptr), MONITOR_DEFAULTTOPRIMARY);
        for (const auto& monitor : current) {
            if (monitor.handle != handle) continue;
            monitors.push_back({nullptr, monitor.device, bounds, work, true});
            return true;
        }
        return false;
    }
    const UINT count = GetPrivateProfileIntW(L"Recovery", L"Count", 0, g_configPath.c_str());
    if (format != 2 || count == 0 || count > kMaxRecoveryMonitors) return false;
    for (UINT index = 0; index < count; ++index) {
        const auto section = RecoverySection(index);
        wchar_t device[CCHDEVICENAME]{};
        GetPrivateProfileStringW(section.c_str(), L"Device", L"", device, CCHDEVICENAME, g_configPath.c_str());
        const RECT bounds = ReadRecoveryRect(section.c_str(), L"Monitor");
        const RECT work = ReadRecoveryRect(section.c_str(), L"");
        if (!device[0] || FindMonitor(monitors, device) || !ValidRectOnMonitor(work, bounds)) return false;
        const bool visible = GetPrivateProfileIntW(section.c_str(), L"TaskbarVisible", 0, g_configPath.c_str()) != 0;
        const UINT dpi = GetPrivateProfileIntW(section.c_str(), L"TaskbarDpi", 0, g_configPath.c_str());
        monitors.push_back({nullptr, device, bounds, work, visible, dpi});
    }
    return true;
}

BOOL CALLBACK NotifyWorkAreaWindow(HWND window, LPARAM shellPid) {
    if (window == g_window) return TRUE;
    DWORD pid{};
    GetWindowThreadProcessId(window, &pid);
    if (pid == static_cast<DWORD>(shellPid)) {
        wchar_t className[128]{};
        GetClassNameW(window, className, 128);
        if (wcscmp(className, L"CabinetWClass") != 0) return TRUE;
    }
    // Hidden browser windows also cache display data. Skip Shell windows, which
    // otherwise immediately reinstate the taskbar reservation on this OS build.
    DWORD_PTR result{};
    SendMessageTimeoutW(window, WM_SETTINGCHANGE, SPI_SETWORKAREA, 0,
                        SMTO_ABORTIFHUNG | SMTO_BLOCK, 100, &result);
    return TRUE;
}

void NotifyApplicationsOfWorkArea(DWORD shellPid) {
    EnumWindows(NotifyWorkAreaWindow, static_cast<LPARAM>(shellPid));
}

struct MaximizedWindowSnapshot {
    HWND window;
    DWORD pid;
    RECT bounds;
    std::wstring device;
    RECT monitorBounds;
    UINT dpi;
};

struct MaximizedWindowCapture {
    DWORD shellPid;
    std::vector<MaximizedWindowSnapshot> windows;
};

BOOL CALLBACK CaptureMaximizedWindow(HWND window, LPARAM context) {
    auto& capture = *reinterpret_cast<MaximizedWindowCapture*>(context);
    if (window == g_window || !IsWindowVisible(window) || !IsZoomed(window)) return TRUE;
    DWORD pid{};
    GetWindowThreadProcessId(window, &pid);
    if (pid == capture.shellPid) {
        wchar_t className[128]{};
        GetClassNameW(window, className, 128);
        if (wcscmp(className, L"CabinetWClass") != 0) return TRUE;
    }
    RECT bounds{};
    MONITORINFOEXW info{};
    info.cbSize = sizeof(info);
    if (GetWindowRect(window, &bounds) &&
        GetMonitorInfoW(MonitorFromWindow(window, MONITOR_DEFAULTTONEAREST), &info))
        capture.windows.push_back({window, pid, bounds, info.szDevice, info.rcMonitor, GetDpiForWindow(window)});
    return TRUE;
}

MaximizedWindowCapture CaptureMaximizedWindows(DWORD shellPid) {
    MaximizedWindowCapture capture{shellPid, {}};
    EnumWindows(CaptureMaximizedWindow, reinterpret_cast<LPARAM>(&capture));
    return capture;
}

RECT AdjustWindowBounds(const RECT& bounds, const RECT& oldArea, const RECT& newArea) {
    // Preserve invisible frame margins, including different DPI on each monitor.
    return {bounds.left + newArea.left - oldArea.left,
            bounds.top + newArea.top - oldArea.top,
            bounds.right + newArea.right - oldArea.right,
            bounds.bottom + newArea.bottom - oldArea.bottom};
}

unsigned int ResizeMaximizedWindows(const MaximizedWindowCapture& capture,
                                    const std::vector<MonitorSnapshot>& before,
                                    const std::vector<MonitorSnapshot>& after,
                                    bool restoreOriginalBounds = false) {
    unsigned int failures = 0;
    for (const auto& snapshot : capture.windows) {
        const auto* oldMonitor = FindMonitor(before, snapshot.device);
        const auto* newMonitor = FindMonitor(after, snapshot.device);
        if (!oldMonitor || !newMonitor || !SameMonitor(*oldMonitor, *newMonitor) ||
            !EqualRectValue(snapshot.monitorBounds, oldMonitor->bounds) ||
            (!restoreOriginalBounds && EqualRectValue(oldMonitor->work, newMonitor->work))) continue;
        if (!IsWindow(snapshot.window) || !IsWindowVisible(snapshot.window) || !IsZoomed(snapshot.window)) continue;
        DWORD pid{};
        GetWindowThreadProcessId(snapshot.window, &pid);
        MONITORINFOEXW currentMonitor{};
        currentMonitor.cbSize = sizeof(currentMonitor);
        if (pid != snapshot.pid ||
            snapshot.dpi != GetDpiForWindow(snapshot.window) ||
            !GetMonitorInfoW(MonitorFromWindow(snapshot.window, MONITOR_DEFAULTTONEAREST), &currentMonitor) ||
            snapshot.device != currentMonitor.szDevice ||
            !EqualRectValue(snapshot.monitorBounds, currentMonitor.rcMonitor)) continue;
        const RECT desired = restoreOriginalBounds ? snapshot.bounds :
                             AdjustWindowBounds(snapshot.bounds, oldMonitor->work, newMonitor->work);
        RECT current{};
        if (!GetWindowRect(snapshot.window, &current) || EqualRectValue(current, desired)) continue;
        // Keep maximized state, focus and Z order. Do not block another UI thread.
        if (!SetWindowPos(snapshot.window, nullptr, desired.left, desired.top,
                          desired.right - desired.left, desired.bottom - desired.top,
                          SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOOWNERZORDER)) ++failures;
    }
    return failures;
}

RECT ReserveTaskbarRect(const RECT& work, const RECT& monitor, const RECT& taskbar) {
    RECT bar{};
    if (!IntersectRect(&bar, &monitor, &taskbar)) return work;
    RECT area = work;
    const LONG width = bar.right - bar.left, height = bar.bottom - bar.top;
    if (width >= (monitor.right - monitor.left) / 2 && height < (monitor.bottom - monitor.top) / 2) {
        if (bar.top == monitor.top) area.top = std::max(area.top, bar.bottom);
        else if (bar.bottom == monitor.bottom) area.bottom = std::min(area.bottom, bar.top);
    } else if (height >= (monitor.bottom - monitor.top) / 2 && width < (monitor.right - monitor.left) / 2) {
        if (bar.left == monitor.left) area.left = std::max(area.left, bar.right);
        else if (bar.right == monitor.right) area.right = std::min(area.right, bar.left);
    }
    return ValidRectOnMonitor(area, monitor) ? area : work;
}

RECT WorkAreaFromTaskbars(const MonitorSnapshot& monitor,
                          const std::vector<TaskbarSnapshot>& taskbars) {
    RECT area = monitor.bounds;
    bool found = false;
    APPBARDATA data{};
    data.cbSize = sizeof(data);
    if (SHAppBarMessage(ABM_GETSTATE, &data) & ABS_AUTOHIDE) return monitor.work;
    for (const auto& taskbar : taskbars) {
        if (taskbar.device != monitor.device || !IsWindowVisible(taskbar.window)) continue;
        RECT bounds{};
        if (GetWindowRect(taskbar.window, &bounds)) {
            area = ReserveTaskbarRect(area, monitor.bounds, bounds);
            found = true;
        }
    }
    return found ? area : monitor.work;
}

bool VerifyWorkAreas(const std::vector<MonitorSnapshot>& expected,
                     const std::vector<MonitorSnapshot>& actual) {
    if (!SameDisplayLayout(expected, actual)) return false;
    for (const auto& monitor : expected) {
        const auto* found = FindMonitor(actual, monitor.device);
        if (!found || !EqualRectValue(monitor.work, found->work)) return false;
    }
    return true;
}

void ReleaseRecovery() {
    g_hidden = false;
    g_originalMonitors.clear();
    ClearRecovery();
}

bool RestoreTaskbar(bool reportError = true) {
    if (!g_hidden) return true;
    std::vector<MonitorSnapshot> before;
    std::vector<TaskbarSnapshot> taskbars;
    DWORD pid{};
    if (!GetDesktopState(before, taskbars, pid)) {
        if (reportError) Error(L"未找到 Windows 任务栏，暂时无法恢复。请待 Explorer 启动后再次运行程序。");
        return false;
    }
    // A fresh Explorer owns fresh state; never inject rectangles from its predecessor.
    if (pid != g_explorerPid) {
        ReleaseRecovery();
        return true;
    }
    const auto windows = CaptureMaximizedWindows(pid);
    g_changingTaskbar = true;
    // HideTaskbar rejects any pre-hidden Shell taskbar, so every captured taskbar
    // was visible before our change. Recreated taskbars also return to normal.
    for (const auto& taskbar : taskbars) ShowWindow(taskbar.window, SW_SHOWNOACTIVATE);
    std::vector<MonitorSnapshot> targets;
    if (!ReadMonitors(targets)) {
        g_changingTaskbar = false;
        if (reportError) Error(L"无法读取当前显示器布局，恢复信息已保留。请再次运行 EXE 重试。");
        return false;
    }
    for (auto& monitor : targets) {
        const auto* saved = FindMonitor(g_originalMonitors, monitor.device);
        const auto* current = FindMonitor(before, monitor.device);
        if (saved && current && CanReuseWorkArea(*saved, *current) && SameMonitor(*current, monitor))
            monitor.work = saved->work;
        else
            // Changed or newly connected displays use current geometry only.
            monitor.work = WorkAreaFromTaskbars(monitor, taskbars);
    }
    bool changed = true;
    DWORD error = ERROR_SUCCESS;
    for (size_t index = 0; index < targets.size(); ++index) {
        RECT area = targets[index].work;
        // Broadcast once, after all monitors have been restored.
        const UINT flags = index + 1 == targets.size() ? SPIF_SENDCHANGE : 0;
        if (!SystemParametersInfoW(SPI_SETWORKAREA, 0, &area, flags)) {
            changed = false;
            error = GetLastError();
        }
    }
    std::vector<MonitorSnapshot> after;
    const bool visible = std::all_of(taskbars.begin(), taskbars.end(), [](const auto& bar) {
        return IsWindow(bar.window) && IsWindowVisible(bar.window);
    });
    const bool verified = changed && visible && ReadMonitors(after) && VerifyWorkAreas(targets, after);
    const unsigned int windowFailures = after.empty() ? 0 : ResizeMaximizedWindows(windows, before, after);
    g_changingTaskbar = false;
    if (!verified) {
        if (reportError) Error(L"部分显示器的任务栏或工作区未完全恢复。恢复信息已保留，请再次运行 EXE 重试；若仍失败，可重启 Windows Explorer。", error);
        return false;
    }
    ReleaseRecovery();
    if (windowFailures && reportError)
        Error(L"任务栏已恢复，但部分最大化窗口未能自动缩回。请检查这些程序是否以管理员权限运行。");
    return true;
}

void RecoverPreviousRun() {
    if (GetPrivateProfileIntW(L"Recovery", L"Active", 0, g_configPath.c_str()) == 0) return;
    std::vector<MonitorSnapshot> current;
    std::vector<TaskbarSnapshot> taskbars;
    DWORD pid{};
    if (!GetDesktopState(current, taskbars, pid)) return;
    const DWORD savedPid = GetPrivateProfileIntW(L"Recovery", L"ExplorerPid", 0, g_configPath.c_str());
    if (pid != savedPid) {
        ClearRecovery();
        return;
    }
    if (!ReadRecovery(g_originalMonitors, current)) {
        Error(L"上次运行的恢复记录不完整，无法安全恢复工作区。请在任务管理器中重新启动 Windows Explorer。");
        return;
    }
    g_explorerPid = pid;
    g_hidden = true;
    RestoreTaskbar();
}

bool HideTaskbar() {
    std::vector<MonitorSnapshot> before;
    std::vector<TaskbarSnapshot> taskbars;
    DWORD pid{};
    if (!GetDesktopState(before, taskbars, pid)) {
        Error(L"无法完整读取 Windows 任务栏和显示器。本工具面向 Windows 11 原生任务栏。");
        return false;
    }
    if (std::any_of(taskbars.begin(), taskbars.end(), [](const auto& bar) { return !IsWindowVisible(bar.window); })) {
        Error(L"部分任务栏当前已被其他程序隐藏。请先恢复任务栏，再使用 TaskbarToggle。");
        return false;
    }
    if (!SaveRecovery(before, pid)) {
        Error(L"无法保存恢复信息，未隐藏任务栏。请检查本地配置目录是否可写。", GetLastError());
        return false;
    }
    g_originalMonitors = before;
    g_explorerPid = pid;
    const auto windows = CaptureMaximizedWindows(pid);
    g_changingTaskbar = true;
    g_hidden = true; // Retain ownership through partial failures and rollback.
    for (const auto& taskbar : taskbars) ShowWindow(taskbar.window, SW_HIDE);
    auto targets = before;
    bool changed = true;
    DWORD error = ERROR_SUCCESS;
    for (auto& monitor : targets) {
        // A monitor without a taskbar keeps its existing reservations unchanged.
        if (!monitor.taskbarVisible) continue;
        monitor.work = monitor.bounds;
        RECT area = monitor.work;
        if (!SystemParametersInfoW(SPI_SETWORKAREA, 0, &area, 0)) {
            changed = false;
            error = GetLastError();
        }
    }
    if (changed) NotifyApplicationsOfWorkArea(pid);
    std::vector<MonitorSnapshot> after;
    const bool hidden = std::all_of(taskbars.begin(), taskbars.end(), [](const auto& bar) {
        return IsWindow(bar.window) && !IsWindowVisible(bar.window);
    });
    bool verified = changed && hidden && ReadMonitors(after) && VerifyWorkAreas(targets, after);
#ifdef TASKBAR_TOGGLE_TEST
    if (g_failHideVerification) verified = false;
#endif
    if (!verified) {
        g_changingTaskbar = false;
        RestoreTaskbar(false);
        // Notifications can have resized only some apps before a failed toggle.
        // Undo those changes from the pre-toggle capture, rather than applying a
        // full-area delta to an app that never expanded.
        ResizeMaximizedWindows(windows, before, before, true);
        Error(L"部分显示器未保持任务栏隐藏或未接受完整工作区。已尝试恢复，核心切换未完成。", error);
        return false;
    }
    const unsigned int windowFailures = ResizeMaximizedWindows(windows, before, after);
    g_changingTaskbar = false;
    if (windowFailures)
        Error(L"任务栏已隐藏，但部分最大化窗口未能自动扩展。请检查这些程序是否以管理员权限运行。");
    return true;
}
