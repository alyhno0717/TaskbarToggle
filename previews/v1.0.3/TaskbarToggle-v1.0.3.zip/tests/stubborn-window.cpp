// Independent GUI process that deliberately ignores work-area notifications.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

LRESULT CALLBACK WindowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    if (message == WM_SETTINGCHANGE && wParam == SPI_SETWORKAREA) return 0;
    if (message == WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProcW(window, message, wParam, lParam);
}

BOOL CALLBACK CreateMonitorWindow(HMONITOR monitor, HDC, LPRECT, LPARAM context) {
    const auto instance = reinterpret_cast<HINSTANCE>(context);
    MONITORINFO info{};
    info.cbSize = sizeof(info);
    if (!GetMonitorInfoW(monitor, &info)) return FALSE;
    HWND window = CreateWindowExW(0, L"TaskbarToggle.IgnoresWorkArea", L"TaskbarToggle work area test",
                                  WS_OVERLAPPEDWINDOW, info.rcWork.left + 20, info.rcWork.top + 20,
                                  480, 320, nullptr, nullptr, instance, nullptr);
    if (!window) return FALSE;
    // Consume Start-Process's hidden startup hint, then maximize on this monitor.
    ShowWindow(window, SW_SHOWMAXIMIZED);
    ShowWindow(window, SW_SHOWMAXIMIZED);
    return TRUE;
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int) {
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    WNDCLASSW cls{};
    cls.lpfnWndProc = WindowProc;
    cls.hInstance = instance;
    cls.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    cls.lpszClassName = L"TaskbarToggle.IgnoresWorkArea";
    if (!RegisterClassW(&cls)) return 1;
    if (!EnumDisplayMonitors(nullptr, nullptr, CreateMonitorWindow, reinterpret_cast<LPARAM>(instance))) return 2;
    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    return 0;
}
