// Opt-in real desktop checks. Independent fixtures are created on every monitor.
#define TASKBAR_TOGGLE_TEST
#include "../main.cpp"
#include <cstdio>

namespace {
DWORD edgePid{}, stubbornPid{};
int failures = 0;
struct Fixture { HWND window; RECT original; std::wstring device; bool edge; };
std::vector<Fixture> fixtures;
BOOL CALLBACK FindFixture(HWND window, LPARAM) {
    DWORD pid{};
    GetWindowThreadProcessId(window, &pid);
    if (!IsWindowVisible(window) || !IsZoomed(window)) return TRUE;
    wchar_t cls[128]{};
    GetClassNameW(window, cls, 128);
    const bool edge = pid == edgePid && wcscmp(cls, L"Chrome_WidgetWin_1") == 0;
    const bool stubborn = pid == stubbornPid && wcscmp(cls, L"TaskbarToggle.IgnoresWorkArea") == 0;
    if (!edge && !stubborn) return TRUE;
    RECT bounds{};
    MONITORINFOEXW info{};
    info.cbSize = sizeof(info);
    if (GetWindowRect(window, &bounds) &&
        GetMonitorInfoW(MonitorFromWindow(window, MONITOR_DEFAULTTONEAREST), &info))
        fixtures.push_back({window, bounds, info.szDevice, edge});
    return TRUE;
}
void Check(bool ok, const char* name) {
    std::printf("%s %s\n", ok ? "PASS" : "FAIL", name);
    if (!ok) ++failures;
}
void CheckFixtures(const std::vector<MonitorSnapshot>& baseline, bool expanded) {
    for (const auto& fixture : fixtures) {
        const auto* monitor = FindMonitor(baseline, fixture.device);
        if (!monitor) { Check(false, "fixture monitor still exists"); continue; }
        const RECT area = expanded && monitor->taskbarVisible ? monitor->bounds : monitor->work;
        const RECT expected = AdjustWindowBounds(fixture.original, monitor->work, area);
        RECT actual{};
        GetWindowRect(fixture.window, &actual);
        std::printf("%ls %s rect=[%ld,%ld,%ld,%ld] expected=[%ld,%ld,%ld,%ld]\n",
                    fixture.device.c_str(), fixture.edge ? "Edge" : "independent",
                    actual.left, actual.top, actual.right, actual.bottom,
                    expected.left, expected.top, expected.right, expected.bottom);
        Check(IsZoomed(fixture.window) && EqualRectValue(actual, expected),
              expanded ? "maximized fixture expands on its own monitor" : "maximized fixture restores original bounds");
    }
}
}

int wmain(int argc, wchar_t** argv) {
    if (argc != 3) return 2;
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    edgePid = wcstoul(argv[1], nullptr, 10);
    stubbornPid = wcstoul(argv[2], nullptr, 10);
    EnumWindows(FindFixture, 0);
    const auto edgeCount = std::count_if(fixtures.begin(), fixtures.end(), [](const auto& f) { return f.edge; });
    if (edgeCount != 1) { std::puts("No unique maximized dedicated Edge window; no desktop changes made."); return 3; }
    std::vector<MonitorSnapshot> baseline;
    std::vector<TaskbarSnapshot> taskbars;
    DWORD pid{};
    if (!GetDesktopState(baseline, taskbars, pid) ||
        std::any_of(taskbars.begin(), taskbars.end(), [](const auto& bar) { return !IsWindowVisible(bar.window); })) return 4;
    std::printf("Active monitors: %zu; Shell taskbars: %zu\n", baseline.size(), taskbars.size());
    for (const auto& monitor : baseline) {
        std::printf("%ls bounds=[%ld,%ld,%ld,%ld] work=[%ld,%ld,%ld,%ld] taskbar=%d\n",
                    monitor.device.c_str(), monitor.bounds.left, monitor.bounds.top, monitor.bounds.right, monitor.bounds.bottom,
                    monitor.work.left, monitor.work.top, monitor.work.right, monitor.work.bottom, monitor.taskbarVisible);
        const auto fixture = std::find_if(fixtures.begin(), fixtures.end(), [&monitor](const auto& f) {
            return !f.edge && f.device == monitor.device;
        });
        Check(fixture != fixtures.end(), "independent maximized fixture exists on each monitor");
    }
    if (failures) return 5;
    g_configPath = L"build\\core-integration-config.ini";
    struct Guard { ~Guard() { RestoreTaskbar(false); } } guard;
    for (int iteration = 1; iteration <= 3; ++iteration) {
        std::printf("Cycle %d%s\n", iteration, iteration == 3 ? " (recovery reload)" : "");
        const bool hidden = HideTaskbar();
        Check(hidden && g_errorCount == 0, "production HideTaskbar succeeds");
        if (!hidden) break;
        Sleep(1000); // Observation delay only; the product has no polling.
        std::vector<MonitorSnapshot> after;
        auto fullAreas = baseline;
        for (auto& monitor : fullAreas) if (monitor.taskbarVisible) monitor.work = monitor.bounds;
        Check(ReadMonitors(after) && VerifyWorkAreas(fullAreas, after), "every monitor retains its intended hidden work area");
        Check(std::all_of(taskbars.begin(), taskbars.end(), [](const auto& bar) { return !IsWindowVisible(bar.window); }),
              "all primary and secondary Shell taskbars stay hidden");
        CheckFixtures(baseline, true);
        if (iteration == 3) {
            // Reconstruct state exclusively from the persisted record, as a new EXE does.
            g_hidden = false;
            g_originalMonitors.clear();
            g_explorerPid = 0;
            RecoverPreviousRun();
            Check(!g_hidden, "production recovery reload restores the desktop");
        } else Check(RestoreTaskbar(), "production RestoreTaskbar succeeds");
        Sleep(300);
        Check(ReadMonitors(after) && VerifyWorkAreas(baseline, after), "all original monitor work areas restored");
        Check(std::all_of(taskbars.begin(), taskbars.end(), [](const auto& bar) { return IsWindowVisible(bar.window) != FALSE; }),
              "all Shell taskbars visible again");
        CheckFixtures(baseline, false);
    }
    RestoreTaskbar(false);
    Check(g_errorCount == 0, "no production error or rollback path triggered");
    std::puts("Injected failed verification (rollback check)");
    g_failHideVerification = true;
    Check(!HideTaskbar(), "failed hide verification reports failure");
    g_failHideVerification = false;
    Sleep(500);
    std::vector<MonitorSnapshot> rolledBack;
    Check(!g_hidden && ReadMonitors(rolledBack) && VerifyWorkAreas(baseline, rolledBack),
          "failed toggle rolls all monitor work areas back");
    Check(std::all_of(taskbars.begin(), taskbars.end(), [](const auto& bar) { return IsWindowVisible(bar.window) != FALSE; }),
          "failed toggle restores every taskbar");
    CheckFixtures(baseline, false);
    Check(g_errorCount == 1, "only the injected failure produced a warning");
    if (!g_hidden) DeleteFileW(g_configPath.c_str());
    std::printf("%d failure(s)\n", failures);
    return failures ? 1 : 0;
}
